# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

Releases: https://github.com/JC-000/c64-polyval/releases — tagged releases
track `MAJOR.MINOR.PATCH` and are the supported consumption points for
downstream projects (see `API.md` §8 for the integration contract).

## v0.10.0 — 2026-09-06

Contract-alignment **MINOR** for
[c64-lib-contract SPEC v1.1.0](https://github.com/JC-000/c64-lib-contract).
Two real conformance gaps closed, one of them a §6.1 MUST that had been
open for the whole life of the archive targets; the rest is docs brought
back into agreement with a specification that lost roughly seven eighths
of its text.

**No behavioural change to any routine.** The POLYVAL, AES-256 and
GCM-SIV code paths are untouched; the PRGs are byte-identical to v0.9.0
on all three profiles. `LIB_POLYVAL_ABI_VERSION` stays **1**.

### What changed in the contract

Contract **v1.0.0** (2026-09-03) cut SPEC.md from 40,737 words to 5,154
under a stated two-prong scope rule — a clause belongs there only if it
governs a name, value or placement two independently-built artifacts must
agree on, **and** a violation is invisible from inside any single
repository's own build. **No symbol, equate, bit value, segment name or
build target changed**, so nothing this library exports had to move.
Retired: §9, §12, §13, §14, §15 and sub-clauses §6.3, §6.6, §6.7.
Surviving sections kept their numbers. **v1.1.0** then added one
normative paragraph to §7 on when `LIB_<X>_ABI_VERSION` moves.

### Added

- **`LIB_POLYVAL_GCMSIV_MAX_PT_LEN = 64`**, exported from
  `src/lib_manifest.s` ([#80](https://github.com/JC-000/c64-polyval/issues/80)).
  §5 asks that a real input ceiling be published there as a symbol a
  consumer can reference, rather than re-derived. Ours existed only as
  `gcmsiv_max_pt_len` in `src/constants_lib.inc` — visible to a consumer
  who *vendors* our source, invisible to one who links the archive as
  §6.1 tells them to, leaving them to hard-code `64` out of prose.
  Deliberately **not** `.ifndef`-guarded, unlike the other four equates
  in that file: it is derived from the value `gcm_siv.s` actually
  compares against, so a `-D` override must collide loudly rather than
  export a ceiling the code does not enforce. Absent from
  `polyval-long.a` / `-short.a` / `-compact.a`, which ship no
  `gcm_siv.o` (§6.4, the issue #23 discipline).
- **`build/lib/polyval.inc` and `build/lib/polyval-example.cfg`**, staged
  by every one of the seven archive targets
  ([#79](https://github.com/JC-000/c64-polyval/issues/79)). §6.1 requires
  `make lib` to produce the archive *plus the consumer-facing `.inc`
  header and an example `.cfg`*; `build/lib/` had only ever held the
  `.a`. A consumer linking the archive therefore had no declaration of
  the public symbols and no statement of the load-bearing segment
  attributes §4 obliges us to declare — both silent at link — so they had
  to read `src/` to link us, which is the mid-build source-poking the
  rest of §6.1 forbids. Copied from `src/polyval_api.inc` and
  `src/polyval-example.cfg` under the §6.1 canonical basenames; both are
  §6.5 name surface from this release.
- **`make consumer-check-shipped`** — a guard that the shipped set is
  actually sufficient. It copies only the three shipped files plus
  `test/consumer_stub_shipped.s` into an empty scratch directory and
  assembles there **with no `-I src`**, so a header depending on an
  unshipped `src/` file fails hard instead of passing invisibly. Every
  other build in this repo has `src/` on the include path and therefore
  cannot see an incomplete shipped surface — which is why #79 survived
  six releases. Shown capable of failing: dropping `polyval.inc` from
  the staged set stops at
  `consumer_stub_shipped.s(39): Error: Cannot open include file`, and
  adding a `.include "constants_lib.inc"` stops at that line instead.
  The link is warning-free, so any future warning from it is signal.
- **`src/polyval-example.cfg`** — a purpose-built consumer template, not
  used by any build in this repo. Shipping `src/lib_only.cfg` was tried
  first and rejected: it carries `make lib-verify` scaffolding (a
  mandatory `LOADADDR` segment, `LIB_POLYVAL_VERIFY_CODE`), so a
  consumer's first link against it emits
  `ld65: Warning: Segment 'LOADADDR' does not exist`, and its opening
  line tells the reader it is for our internal verification build.

### Changed

- `src/precalc_table.inc` refreshed from the v1.1.0 canonical. Comment-only
  (the contract's own 1.0.0 entry notes adopters' copies need not be
  refreshed), but one of the comments had become false — see below.
- `API.md` §9 rewritten. Its preamble was a version-by-version narrative of
  the contract's growth from v0.1.0 to v0.11.1 — the genre the contract
  itself has just deleted as out of scope. Replaced with the current
  surface, a table of which sections apply, and an explicit account of
  where the retired clauses' obligations went. §9.5 now groups §6.3, §6.6
  and §6.7 under a "retired clauses" heading rather than presenting them
  as live conformance.
- `CLAUDE.md`'s contract section rewritten on the same basis.
- `README.md`'s contract section updated for the new shipped surface and
  the published bound.

### Fixed

- **`lda #LIB_POLYVAL_GCMSIV_MAX_PT_LEN` does not assemble** — an
  `.import`ed symbol has no value until link, so ca65 cannot prove it
  fits a byte and reports `Range error`. Consumers must write
  `lda #<LIB_POLYVAL_GCMSIV_MAX_PT_LEN`. Not a defect in the export (it
  applies to every imported §5 scalar) but it is the first thing a
  consumer hits, so it is now documented in `API.md` §9.4, in the
  example cfg's trailing comment, and exercised in
  `test/consumer_stub_shipped.s`.
- **`tools/build_release.sh` would have silently omitted the new example
  cfg from the release tarball.** Its `src/` staging enumerated
  `src/c64.cfg src/lib_only.cfg` by name while globbing `src/*.s` and
  `src/*.inc`, so `src/polyval-example.cfg` — the file §6.1 tells
  consumers to expect — simply would not have been in the archive, with
  no diagnostic from the script, from `make dist`, or from the
  reproducibility re-run. Now globs `src/*.cfg`, removing the
  silent-omission class rather than adding one more name to remember.
  Same shape as the `docs/*.md` trap already flagged in `CLAUDE.md`.
- Statements that had become **false going forward**, as opposed to merely
  citing a retired section number: the bare `LIB_VERSION_*` exports were
  documented in four places as "removed at contract v1.0", which contract
  v1.0.0 explicitly **deferred to a future MAJOR** rather than doing —
  `src/lib_version.s`, `src/lib_manifest.s`, `src/precalc_table.inc`,
  `API.md`, `README.md`.
- `API.md` §9.4 said one tag carries "four footprint pairs". It has carried
  seven since v0.8.0 — the count was against a stale archive list rather
  than against the `lib-polyval-*` target list, which is exactly the
  failure mode the surrounding prose warns about.

### Assessed, no change

- **`LIB_POLYVAL_ABI_VERSION` holds at 1** under the new §7 paragraph. The
  v0.9.0 length-rejection return is superficially the shape §7 says moves
  the counter, but `gcmsiv_encrypt` documented no return convention at all
  at v0.8.0 (§7's "previously undocumented becomes documented" limb), and
  `gcmsiv_decrypt`'s reject path was written to be indistinguishable from a
  tag failure on every documented post-condition, so its return set did not
  gain a value. The second of those is a property of `@reject_len` in
  `src/gcm_siv.s` and not a general fact: if that path is ever made
  distinguishable from a tag failure, the counter moves. Put to the
  contract for arbitration as
  [c64-lib-contract#180](https://github.com/JC-000/c64-lib-contract/issues/180),
  because v1.1.0's fleet position names three sibling libraries and not
  this one, which shipped the same shape in the same week. Reasoning
  recorded in `API.md` §9.1 and `CLAUDE.md`.
- **Retired-section citations elsewhere in this repository are deliberately
  left as written** — in `CHANGELOG.md`, in `docs/RELEASE_NOTES_v0.*.md`,
  and in the in-line `§6.6` comments in `src/lib_manifest.s`. Each is a
  claim about the tagged revision it was made against and still resolves
  at `git show v0.17.1:SPEC.md`; the contract's own `RETIRED.md` asks
  adopters not to churn them. `src/lib_manifest.s` gained one header note
  saying where the §6.6 obligation lives now, in place of rewriting
  thirteen in-line citations.
- **The §6.3 machinery is kept as local engineering**, not conformance: the
  `PIN_` parse-time goal table, the `build/.ca65flags` stamp and
  `tools/check_knob_staleness.sh` all stay exactly as they are. They are
  good properties for this Makefile independent of any clause requiring
  them.
- §1 and §8.4 zero-consumer carve-outs remain N/A — `c64-aes256-ecdsa`
  pins a tag, so the bare exports and the bare `LIB_PRECALC_<name>_*`
  triple keep shipping, gated on `LIB_NO_BARE_EXPORTS`.

## v0.9.0 — 2026-08-31

Hardening **MINOR** from an adversarial audit of the library against
`cryptography.hazmat` as an independent oracle (2026-08-28). Two latent
defects fixed, one documentation error corrected, and the test suite
rebuilt so that the checks which found them are permanent and have been
demonstrated capable of failing.

No cryptographic divergence was found: POLYVAL and AES-256-GCM-SIV agree
with hazmat and with an independently written RFC 8452 oracle on all
three profiles, across adversarial `H` values, message shapes to 1 KiB,
all-zero and all-`FF` keys and nonces, every message length 0..64, CTR
counter wrap at every byte boundary, and an exhaustive single-bit
forgery sweep. Both defects were reachability and memory-safety issues
around the AEAD entry points, not errors in the field arithmetic.

**Verification is now three profiles, not one.** `run_all_tests.py`
previously built with a plain `make` and certified the LONG profile
only; SHORT and COMPACT shipped uncertified by the documented entry
point. The runner now sweeps all three by default: **1253 passed, 6
skipped, 0 failed per profile** (the 6 skips remain the RFC 8452
non-empty-AAD vectors, which GCM-SIV intentionally does not support).


### Added

- **Test harness hardening from the 2026-08 hazmat audit** (issues
  [#72](https://github.com/JC-000/c64-polyval/issues/72),
  [#73](https://github.com/JC-000/c64-polyval/issues/73),
  [#74](https://github.com/JC-000/c64-polyval/issues/74),
  [#75](https://github.com/JC-000/c64-polyval/issues/75)); no library
  code changes.
  - `tools/hazmat_oracle.py` — independent, self-verifying POLYVAL /
    AES-256-GCM-SIV oracle written from the RFC 8452 text (schoolbook
    carry-less multiply + explicit reduction, x^-128 by exponentiation
    and checked against the `1 + x^-1 + x^-2 + x^-7` identity,
    pure-Python FIPS-197 AES-256). Not derived from
    `polyval_reference.py`. `cryptography` is optional: when present its
    AES-ECB and `AESGCMSIV` are cross-checked on import, when absent
    those checks are reported as skipped.
  - `tools/test_hazmat_fuzz.py` — the audit's 6-section differential
    driver (adversarial H / message shapes to 1 KiB, multiply edge
    operands, all-0/all-FF keys and nonces at every length 0..64, key
    derivation, CTR wrap at every byte boundary, exhaustive 128 + 136 +
    96 single-bit forgery sweep asserting `A=1` and the `dec_buf` wipe).
    `--seed N|random`, `--iterations N`, `--profile P`; hazmat
    cross-checks become counted SKIPs without `cryptography`.
  - `tools/test_gcmsiv_bounds.py` — regression tests for issues
    [#69](https://github.com/JC-000/c64-polyval/issues/69) (256-byte
    copies into the 240-byte `aes_expanded_key`; the 16-byte window is
    located from the label file, poisoned, and must survive
    `gcmsiv_install_enc_key` / `gcmsiv_restore_orig_key`) and
    [#70](https://github.com/JC-000/c64-polyval/issues/70)
    (`gcmsiv_encrypt` / `gcmsiv_decrypt` with `pt_len` 65 and 128 must
    return `A=1`, decrypt must wipe `dec_buf`, and neither may touch the
    surrounding buffers). Demonstrated capable of failing: these 8 of
    15 checks were RED on every profile against the pre-fix tree and
    green after [#76](https://github.com/JC-000/c64-polyval/pull/76),
    with no other suite changing.
  - `tools/run_all_tests.py` gains `--profile {long,short,compact,all}`
    (default `all`; SHORT and COMPACT were never exercised by the
    documented entry point — #72), `--fuzz-iterations`, `--seed random`,
    a per-profile summary plus a final combined table, three VICE
    instances per profile, and calls `cross_validate_reference()` once
    before the profile loop (#74 T-3).
  - `tools/vectors/rfc8452_vectors.json` carries RFC 8452 C.2 #4 (16-byte
    PT, empty AAD) and #17 (non-trivial key/nonce, empty PT/AAD),
    transcribed from the RFC text and verified by the oracle; entries are
    now named by their RFC ordinal (#74 T-6).

### Fixed

- **`gcmsiv_install_enc_key` / `gcmsiv_restore_orig_key` / the
  `@copy_exp` loop in `gcmsiv_derive_keys` copied 256 bytes into the
  240-byte `aes_expanded_key`** (`inx / bne` with no terminator).
  Found by the 2026-08-28 `cryptography.hazmat` differential audit,
  finding I-1, [#69](https://github.com/JC-000/c64-polyval/issues/69).
  The 16 bytes past the schedule (`aes_mc_*` and `gcmsiv_nonce[0..7]`
  in the shipped layout; whatever a consumer's linker places there in
  general) were snapshotted at `gcmsiv_derive_keys` time, transiently
  overwritten with that snapshot during every `gcmsiv_finalize_tag` /
  `gcmsiv_ctr_encrypt` / `gcmsiv_ctr_decrypt` window, and any write to
  them inside the window (an IRQ handler, say) was silently reverted by
  the restore. Not observable through the documented API sequence —
  the nonce is read before install and never inside the window, so
  every test vector passed — but a latent memory-safety defect for
  consumers with a different placement. All three loops now terminate
  at `aes_expanded_key_size` (240, `src/constants_lib.inc`), and
  `gcmsiv_exp_enc_key` / `gcmsiv_saved_exp` in `src/data.s` shrink from
  256 to 240 B each (`LIB_POLYVAL_GCMSIV_BSS` is 32 B smaller; the
  manifest `RESIDENT_BYTES` / `COLD_BYTES` count code+rodata only and
  are unchanged — see the re-measured figures under I-2 below).

- **`gcmsiv_encrypt` / `gcmsiv_decrypt` did not validate
  `gcmsiv_pt_len`**, and `gcmsiv_pt_len` was the byte immediately after
  the 64-byte `gcmsiv_pt_buf`. Hazmat audit finding I-2,
  [#70](https://github.com/JC-000/c64-polyval/issues/70). With
  `pt_len = 65` the 65th plaintext byte read was the length byte
  itself and ciphertext byte 64 landed in `gcmsiv_dec_buf[0]`; with
  `pt_len >= 128` `gcmsiv_compute_tag_base` hashed no data blocks at
  all (only the length block) while CTR wrote `pt_len` bytes across
  `gcmsiv_dec_buf`, `gcmsiv_tag`, the derived keys, the live counter
  and keystream. Out of contract (API.md §6 item 4 documents 0..64),
  but the routine returned normally with a wrong tag. Both entry
  points now check `gcmsiv_pt_len` before touching any state and
  reject `> gcmsiv_max_pt_len` (new equate, 64, `constants_lib.inc`)
  with `A=1` / `Z=0` — the existing tag-failure convention.
  `gcmsiv_encrypt` writes nothing on rejection (and now returns
  `A=0` / `Z=1` on success, where A was previously undefined);
  `gcmsiv_decrypt` wipes `gcmsiv_dec_buf` and clears
  `gcmsiv_tag_valid` exactly as a bad tag does, and leaves
  `gcmsiv_tag` as received. The lower-level `gcmsiv_compute_tag_base`
  / `gcmsiv_ctr_*` steps still do not check. `src/data.s`
  additionally moves `gcmsiv_pt_len` after `gcmsiv_dec_buf` as defence
  in depth — **`LIB_POLYVAL_GCMSIV_BSS` ordering changed** (consumers
  that hard-coded buffer offsets relative to each other rather than
  importing the labels must re-link; every buffer keeps its size and
  segment membership).

  Footprint: `LIB_POLYVAL_GCMSIV_CODE` grows 805 → 847 B across #69
  and #70, so the measured AEAD `RESIDENT_BYTES` are now 6609 (LONG),
  16063 (SHORT), 2774 (COMPACT) — every declared value (6656 / 16128 /
  2816) is unchanged; `COLD_BYTES` and the three POLYVAL-only archives
  are unaffected. PRG sizes: LONG 9474 → 9516 B, SHORT 18928 → 18970 B,
  COMPACT 5639 → 5681 B (not byte-identical to v0.8.0, by design).

- **`polyval_precompute_table` was documented as clobbering
  `polyval_h`; it preserves it on every profile.** Hazmat audit
  finding D-1, [#71](https://github.com/JC-000/c64-polyval/issues/71).
  `API.md` §6 item 1 and the routine headers in `polyval_long.s` /
  `polyval_short.s` said `polyval_h` "holds H'" after the call and
  asked hosts to save H first; the audit measured `polyval_h`
  byte-identical after precompute on LONG, SHORT and COMPACT for every
  H tried, and no back-end contains a store to it (LONG shifts a copy
  in `polyval_acc`, SHORT/COMPACT in `polyval_temp`). Text carried
  since v0.1.0; the save it prescribed was harmless. Same item 7's
  "~30k cy (SHORT) ... 128 right-shifts" was the pre-identity figure
  v0.8.0 corrected elsewhere; now 4,656 cy SHORT / 10,970 cy COMPACT
  / 255,268 cy LONG. Doc-only; no code or PRG change.

- `tools/test_gcmsiv_polyval.py` round-trip starvation
  ([#73](https://github.com/JC-000/c64-polyval/issues/73)): the random
  round-trip budget was `iterations - (2 x no-AAD vectors + 1)`, which at
  the default 15 left room for only the 1- and 15-byte cases — the
  16/17/32/48/63/64 boundaries and the random-length loop never ran. The
  boundary lengths now always run and the random loop runs exactly
  `--iterations` times.
- `tools/test_gcmsiv_polyval.py` negative tests
  ([#74](https://github.com/JC-000/c64-polyval/issues/74) T-5): tag
  bit-flip coverage went from 24 to all 128 positions, plus every bit of
  a 17-byte ciphertext and every bit of the nonce; every rejection now
  asserts the documented return convention (`A=1`, Z clear) and the
  64-byte `gcmsiv_dec_buf` wipe (previously only `gcmsiv_tag_valid` was
  read), and valid decrypts assert `A=0`.
- `tools/test_polyval_direct.py` accepts `--seed random` (#74 T-7).
- Per-profile expected counts are now 1253 pass / 6 skip (was 376/6 for
  LONG only); `README.md` and `CLAUDE.md` updated.

- Documentation left describing two profiles after v0.8.0 added a third.
  Caught in a post-tag sweep; **v0.8.0's tag, tarball and release asset
  are unaffected and remain the canonical artifact** — these are
  corrections to `master`, and `make dist VERSION=v0.8.0` from `master`
  no longer reproduces the tagged tarball's hash by design. The
  substantive one:

  - `API.md` §3's "Read the Code column" paragraph still concluded that
    a consumer choosing on size "is choosing between ~13.5 KB and
    ~12.3 KB, and LONG is the smaller of the two". True of SHORT vs
    LONG, and actively misleading with COMPACT shipped at 613 B —
    roughly 20x under either. Now scoped to the SHORT/LONG pair and
    pointing at COMPACT for the size question. (Also `~13.5` -> `~13.6`
    KB, matching the table two paragraphs above it.)

  Follow-ups from the review of
  [PR #67](https://github.com/JC-000/c64-polyval/pull/67): the §7
  fragment's guard caught only an *empty* selection, but `$(filter)`
  matches per word, so `POLYVAL_PROFILE_VAL="1 2"` passed it and
  selected two back-ends at once. Now `$(words …) != 1`, which
  subsumes the empty case and matches the top-level `Makefile`, whose
  `ifeq`-chain-on-a-name form already rejected the analogous
  `POLYVAL_PROFILE="short long"`. Also: `tools/test_polyval_direct.py`
  and `tools/test_gcmsiv_polyval.py` described the `POLYVAL_PROFILE`
  read as "dual-path selection" directly above a three-way lookup —
  the files that made COMPACT's 376/376 checkable with no test change.

  Alongside it: the §7 consumer Makefile fragment mapped
  `POLYVAL_PROFILE_VAL` to `polyval_short`/`polyval_long` with a binary
  `$(if)`, silently selecting LONG for `=3`; it now handles all three
  and rejects anything else (verified against GNU Make 3.81, the macOS
  system make, for all three values plus the default and an invalid
  one). `src/exports.inc` gained its `polyval_compact.s` section and a
  note that exactly one back-end links. REU/turbo prose in `API.md` §3
  and §9.3 said "neither profile" / "either profile"; `src/data.s` and
  `src/polyval_api.inc` comments said "both profiles"; `README.md` and
  `CLAUDE.md` described the byte-identity receipt as covering "both
  profiles".

### Compatibility

- **ABI unchanged: `LIB_POLYVAL_ABI_VERSION` stays `1`.** No exported
  symbol was removed or renamed. `gcmsiv_max_pt_len` is a new equate in
  `src/constants_lib.inc`; additions alone do not move the ABI counter.
- **`LIB_POLYVAL_GCMSIV_BSS` shrank 881 → 849 B and its ordering
  changed.** `gcmsiv_pt_len` now
  sits after `gcmsiv_dec_buf` instead of immediately after
  `gcmsiv_pt_buf`. Every buffer keeps its size and segment membership,
  and consumers that `.import` the labels are unaffected — but a
  consumer that hard-coded one buffer's offset *relative to another*
  rather than importing must re-link. This is the one change in this
  release that can require action from a consumer.
- **`gcmsiv_encrypt` now defines `A` on success** (`A=0` / `Z=1`),
  where it was previously undefined. Existing callers that ignored the
  register are unaffected; the rejection path returns `A=1` / `Z=0`,
  matching the tag-failure convention `gcmsiv_decrypt` already used.
- **PRGs are not byte-identical to v0.8.0, by design** — the fixes add
  code. LONG 9474 → 9516 B, SHORT 18928 → 18970 B, COMPACT 5639 →
  5681 B. This release makes no byte-identity claim.
- Every declared §6.6 `RESIDENT` / `COLD` footprint value is unchanged
  from v0.8.0; the measured AEAD figures grew by 42 B and remain inside
  the declared, 256-byte-rounded envelope. Per-archive rows are in
  `docs/RELEASE_NOTES_v0.9.0.md`.

## v0.8.0 — 2026-08-23

Feature **MINOR**: a third `POLYVAL_PROFILE`, **COMPACT** — a rolled
Shoup-4 back-end whose multiply assembles to **325 bytes**, against
SHORT's 13,614 and LONG's 4,160. Closes issue
[#51](https://github.com/JC-000/c64-polyval/issues/51), filed from
`c64-aes256-ecdsa` after that consumer's v0.7.1 integration.

**The gap it closes is a memory-map decision, not a size preference.**
SHORT and LONG both trade *table* memory for speed and assume code is
cheap; on a stock C64 the ~38 KB below the `$A000-$BFFF` BASIC ROM
window is the real budget, and a 13.6 KB multiply can be what pushes a
consumer's image into that window. `c64-aes256-ecdsa` measured exactly
that: reading `polyval_multiply` on the running machine returned
BASIC's `ILLEGAL QUANTITY` text and `polyval_precompute_table` wedged
the CPU at `$A005`. The failure mode is the CPU executing ROM, not a
link error.

### Added

- `src/polyval_compact.s` — `POLYVAL_PROFILE=compact` /
  `-D POLYVAL_PROFILE=3`, segment `LIB_POLYVAL_COMPACT_CODE`. Same
  mathematics, same 256-byte `polyval_htable` and the same public
  symbol set as SHORT, with the 32 straight-line nibble steps and the
  unrolled table build rolled back into loops. Register-preservation
  contracts match SHORT and LONG per routine, including where matching
  costs a stack round-trip — a consumer swapping profiles does not have
  to re-read the per-routine Exit blocks.
- Two §6.1 archive targets, `make lib-polyval-compact` and
  `make lib-polyval-gcmsiv-compact`, with `PIN_` rows so a
  mismatched invocation is rejected at parse time like every other
  archive goal. Profile is a member-set axis (SPEC §6.3), so a new
  profile takes targets, never a `CONTRACT_DEFINES` `-D`.
- Two §6.6 footprint pairs: `polyval-compact.a` RESIDENT 512 / COLD
  256 (measured 325 / 147), `polyval-gcmsiv-compact.a` RESIDENT 2816
  / COLD 512 (measured 2732 / 339). COMPACT places its cold code last
  in its segment so the overlayable region is contiguous, and is the
  first configuration where the `LIB_POLYVAL_NO_AES` gating actually
  moves a COLD value (512 → 256) rather than rounding to the same
  boundary.
- `make consumer-check-noaes` now links the issue-#47 stub against
  `polyval-compact.a` as well.

### Fixed

Two stale figures in `API.md` §3 / `README.md`, both dating to v0.1.0,
both found by re-measuring rather than by reading the prose.

- **SHORT's precompute was documented as ~29,385 cy; it is 4,656 cy.**
  The figure predates the release that replaced the 128-iteration
  `mulX_POLYVAL` loop with the 7-shift RFC 8452 identity — a ~6×
  overstatement that survived because nothing re-measured it. LONG's
  255,268 cy and both multiply figures re-measured within noise of
  their documented values.
- **The "practical break-even ≈ 68 blocks" is withdrawn.** It was
  introduced in `959ffd8` with no derivation, immediately after that
  commit's own analytic crossover, and it hangs off the same
  `precompute + N × update` model and the same v0.1.0 measurement pass
  as the figure above. Its own gloss contradicted it: 1 KB of plaintext
  is 64 blocks, not 68.

  **The SHORT/LONG crossover is 17 blocks (272 bytes)**, now measured
  end-to-end rather than solved — SHORT ahead by 10,309 cy at N=16,
  LONG ahead by 4,806 at N=17, margin widening monotonically after
  (708,242 cy at N=64). There is exactly one crossover:
  `total_SHORT(N) − total_LONG(N)` is linear with a single root, and
  measured per-block cost is flat to 0.5% from N=14 to N=256 on both
  profiles, so no second break-even exists for the old figure to name.
  §3 now carries the equation and the measurement table so the number
  is checkable without a rebuild, and `README.md` and `API.md` use one
  word for it.

  *An earlier draft of this release certified the 68-block figure as
  "unaffected" by the precompute correction. That certification had no
  basis — correcting SHORT's precompute downward pushes crossovers
  later, so if 68 depended on the model at all it moved too. Caught in
  review of [PR #63](https://github.com/JC-000/c64-polyval/pull/63)
  before tagging.*

### Changed

- `tools/benchmark_polyval.py`'s multi-block sweep is overridable via
  `POLYVAL_BENCH_BLOCKS` (default unchanged: `1,4,16,64,256`), so the
  crossover measurement above is reproducible. Repo-side tool, not
  vendored in the release tarball.
- **The same sweep no longer picks its timing wrapper from a stale
  constant** (issue
  [#65](https://github.com/JC-000/c64-polyval/issues/65)). It projected
  `n * 7200` cy/block — commented "current Shoup: `polyval_update`
  ~7085 cy", a back-end predating both current 4-bit profiles — and so
  kept the 16-bit CIA Timer A wrapper selected through N=7 while the
  real cost passed its 65,535 range far earlier. Measured per-block
  cost is 4,241 (LONG), 19,218 (SHORT), ~49,950 (COMPACT), giving a
  wrapped-value band of **N=4…7 on SHORT and N=2…7 on COMPACT**; the
  default sweep contains N=4, so every SHORT and COMPACT run tabled one
  fictional row (`-21` cycles).

  The sweep now uses the chained 32-bit wrapper unconditionally — no
  re-tuned constant, which would age out just as silently — plus two
  backstops: a non-positive measurement raises instead of being tabled,
  and an ascending sweep is checked for monotonicity in N. Where the
  two wrappers overlap they agree to ~0.2%, so nothing is lost.

  Third instance of the pattern this release keeps finding: a v0.1.0-era
  constant nobody re-took, failing in a direction that reads as data.
  This one had an inverted tell — the wrap is *deterministic*, so the
  bad rows reported `spread = 0` while every honest row carried the
  `(!)` noise marker, making the fiction look like the cleanest data on
  screen. Found by JC-000 while independently reproducing the crossover
  table in [PR #64](https://github.com/JC-000/c64-polyval/pull/64).

  No shipped artifact is affected — `tools/` is not vendored — and the
  §3 crossover table is unchanged: N=14…20 always sat in the good band,
  and the corrected sweep reproduces those margins within spread.

### Notes

- No exported symbol was added, removed or renamed, so
  `LIB_POLYVAL_ABI_VERSION` stays `1`. The LONG and SHORT profiles are
  untouched: no `.o` under either profile changed, and their footprint
  equates are unchanged.
- Correctness: 376/376 tests pass under `POLYVAL_PROFILE=compact`
  (217 direct POLYVAL + 159 GCM-SIV, 6 RFC 8452 AAD vectors skipped as
  documented), against the same Python reference and the same vectors
  as the other two profiles.
- COMPACT is **strictly slower than SHORT at every message length** —
  49,657 cy per multiply against 18,776 — and is not a third point on
  the speed/memory axis. It is chosen on footprint alone.

## v0.7.3 — 2026-08-23

*(Footprint table presentation corrected before tagging: one row per
shipped archive, five archives and five rows. v0.7.0–v0.7.2 combined
`polyval.a` and `polyval-gcmsiv.a` — same configuration, same values —
into one row while the prose said "five rows", so the release flow's own
row-count check could not be performed as written. Values were correct
throughout; `CLAUDE.md` is corrected so future notes stay literal.
Caught in review of PR #61.)*

Build-correctness **PATCH**, all three parts of one defect class: a
consumer's `-D` reaching `ca65` but not reaching make's dependency graph.
SPEC v0.11.1 §6.3 splits the treatment by whether the build *can* honor
the knob — member-set axes **reject** at parse time (#55), configuration
axes **invalidate** (#58) — and a pin now holds both in place. No
exported surface changed, no declared footprint moved, PRG
byte-identical to v0.7.2, so `LIB_POLYVAL_ABI_VERSION` stays 1.

Side effect worth noting: the profile-switch gotcha is retired. `make
POLYVAL_PROFILE=short` straight after `make` now produces the SHORT PRG
rather than a stale LONG one.

Contract currency moves **v0.11.0 → v0.11.1**, whose §6.3 split is the
rule this release implements. The `CONTRACT_DEFINES` member-set
`$(error)` from #55 is cited **by name** in that clause as the shipped
exemplar for the reject branch. v0.11.1 is merged on the contract's
`main` but not yet tagged there (latest tag v0.11.0).

### Added

- **`tools/check_knob_staleness.sh`, run as a leg of `make lib-verify`** —
  the pin SPEC §6.3 requires for the invalidate branch, raised in review
  of [PR #59](https://github.com/JC-000/c64-polyval/pull/59). The #58 fix
  was correct but unprotected: a refactor moving the `CA65FLAGS`
  composition below the stamp would silently reopen it with nothing
  failing. The other three fleet adopters each have such a pin; this
  library had none.

  It asserts the **artifact** flipped, never that "something rebuilt" —
  §6.3's stated distinction, and the one that matters, since an
  unconditional rebuild wearing a stamp satisfies "something rebuilt"
  while destroying incremental builds. Checks: both knobs flip on a warm
  tree; both flip **back** when the knob is removed (the direction a
  consumer hits when they finish debugging and drop the flag); all nine
  objects survive every transition (the failure mode of the rejected
  delete-from-a-prerequisite mechanism); an unchanged invocation
  recompiles **0** TUs; and #55's member-set rejection still fires.

  Runs in its own scratch `BUILD_DIR`, so it cannot disturb `build/`.

  `--selftest` proves the pin can fail, by disabling the stamp via
  `CONTRACT_FLAGS_WAS='$(CONTRACT_FLAGS_NOW)'` — a command-line override
  that makes the parse-time comparison compare a value to itself, with no
  hardcoded flag string to drift. Verified end-to-end against the real
  regression: run against the pre-#59 `Makefile` the pin fails with the
  exact #58 symptom (`left zp_config.o at 13 exports, expected 0`), and
  passes against the fixed one. A pin never seen to fail is not a pin —
  the review noted x25519's first attempt disabled its stamp with an
  always-true condition, passed, and meant nothing.

### Fixed

- **Configuration axes via `CONTRACT_DEFINES` were silently dropped on a
  warm tree** ([issue
  #58](https://github.com/JC-000/c64-polyval/issues/58), measurements
  from [#57](https://github.com/JC-000/c64-polyval/issues/57) which it
  supersedes). The invalidate half of #55: the defines PR #56 correctly
  still *accepts* — `LIB_NO_BARE_EXPORTS`, `ZP_CONFIG_NO_EXPORTS`, ZP
  slot overrides — reach every `ca65` invocation but no make
  prerequisite, so they were honoured from a clean tree and ignored from
  a warm one:

  ```
  $ make clean && make lib
  $ make lib CONTRACT_DEFINES="-D ZP_CONFIG_NO_EXPORTS=1"
  make: Nothing to be done for `lib'.        # exit 0
  $ od65 --dump-exports build/zp_config.o | grep -c Name:
  13                                         # asked for 0
  ```

  This made the #50 advice wrong in practice: that fix is real, but a
  consumer iterating locally — the normal way to work through a ZP
  overlap — saw the knob apparently do nothing. Per contract SPEC
  v0.11.1 §6.3's two-branch rule these axes take the *invalidate* branch,
  not #56's reject branch, since they genuinely work.

  Fixed with a **parse-time flag stamp** (`build/.ca65flags`) that
  deletes stale objects and archives when the effective `CA65FLAGS`
  differs from the previous invocation. Unchanged flags delete nothing,
  so incremental builds still short-circuit.

  **Two simpler mechanisms were measured failing first**, recorded in
  the Makefile so they aren't reintroduced. macOS ships GNU Make 3.81,
  which compares mtimes at 1-second granularity: a stamp-as-prerequisite
  compared by timestamp is newer only in the sub-second digits
  (`…455.095994194` vs `…455.036999740`) and same-second rebuilds are
  skipped. Making that stamp *delete* instead fails differently — 3.81
  stats a target before running its prerequisites' recipes and caches
  the result, so the delete is invisible for whichever object make
  considered first; measured, `build/lib_version.o` was deleted and then
  **not** rebuilt, silently dropping a member from the archive, which is
  worse than the staleness being fixed.

  Side effect: this **retires the profile-switch gotcha**. `make
  POLYVAL_PROFILE=short` straight after `make` now produces the SHORT
  PRG instead of a stale LONG one, so the manual `make clean` between
  profile switches is no longer required. `CLAUDE.md` is updated.

  Verified: both knobs and a ZP slot override flip correctly on a warm
  tree in both directions; identical repeat invocations trigger **0**
  recompiles (including a whitespace-variant invocation, which `$(strip)`
  normalises); all nine objects present after every transition; #56's
  member-set rejections still fire; all five archive targets,
  `consumer-check` and `consumer-check-noaes` build; PRG byte-identical
  to v0.7.2; suite 376/376 passed, 6 skipped.

- **`CONTRACT_DEFINES` walked past the archive-goal configuration guard**
  ([issue #55](https://github.com/JC-000/c64-polyval/issues/55)). The
  issue #40 `PIN_` table guards the *make variable* route, but SPEC
  §6.2's consumer mechanism is `CONTRACT_DEFINES`, which is appended to
  `CA65FLAGS` — and a member-set axis routed that way cannot work, since
  no ca65 `-D` reaches member selection. Both axes were measured
  bypassing the guard:

  - `make lib CONTRACT_DEFINES="-D POLYVAL_PROFILE=1"` gave **opposite
    answers decided only by whether `build/` was warm**: a ca65
    `'POLYVAL_PROFILE' is already defined` (exit 2) from clean, versus
    `Nothing to be done` (exit 0) from warm — with `polyval.a` still
    holding `polyval_long.o`. The consumer asked for SHORT, got LONG,
    got exit 0. Five TUs branch on `POLYVAL_PROFILE`, and the stale
    `lib_manifest.o` reports the other profile's §5 footprint and §8.0
    rows, which no downstream assert catches.
  - `make lib CONTRACT_DEFINES="-D LIB_POLYVAL_NO_AES=1"` was **worse,
    and was not in the report**: exit 0 with no diagnostic at all, even
    from a clean tree. Every TU assembles NO_AES while `lib` archives
    the full AEAD member list, so `data.o` drops the AES/GCM-SIV BSS
    that the archived `aes_encrypt.o` still references. Measured: the
    archive is unlinkable (`Unresolved external 'aes_expanded_key'`)
    *and* its manifest exports the NO_AES `RESIDENT` (4352) for an AEAD
    member set — §6.4-incoherent and wrong on both axes at once.

  Both now reject at parse time, before anything is built, per SPEC
  §6.3's looks-reachable rule: a knob naming an axis MUST select it or
  reject loudly, and these cannot select it. The state-dependence was
  the sharpest edge — a diagnostic that fires from clean and stays
  silent from a warm tree is worse than one that never fires, because a
  consumer probing interactively concludes the define was accepted.

  `CONTRACT_DEFINES` / `CONTRACT_ZP_DEFINES` remain correct for
  non-member-set defines; `LIB_NO_BARE_EXPORTS`, `ZP_CONFIG_NO_EXPORTS`
  and ZP slot overrides are regression-tested alongside all five archive
  targets. `build/polyval.prg` byte-identical to v0.7.2; suite 376/376
  passed, 6 skipped.

## v0.7.2 — 2026-08-23

Consumer-reachability **PATCH**. `ZP_CONFIG_NO_EXPORTS` was assigned
unguarded in a header every library TU includes, so the documented
supplies-own-slots route was a hard assemble error rather than a
working knob. Also corrects `API.md` §3, whose single "Memory (tables)"
column hid the fact that SHORT's *code* is 13.6 KB. No exported surface
changed, no declared footprint moved, PRG byte-identical to v0.7.1, so
`LIB_POLYVAL_ABI_VERSION` stays 1.

### Documentation

- **`API.md` §3 gains Code / Tables / Total RAM columns** ([issue
  #51](https://github.com/JC-000/c64-polyval/issues/51)). The table
  presented the profile axis as a speed-vs-memory trade with a single
  "Memory (tables)" column — `~256 B` for SHORT — which is true and
  materially misleading: SHORT's multiply is a fully unrolled Shoup-4
  and its *code* is 13,614 B. A consumer choosing on "which profile is
  smaller" was reading the one column that hides the answer.

  Measured, not estimated (segment sizes from a `lib_only.cfg` link of
  each POLYVAL-only archive): SHORT 13,614 B code + 256 B tables ≈ 13.5
  KB total; LONG 4,160 B code + 8,448 B tables ≈ 12.3 KB total. **LONG
  is the smaller profile overall** — the names describe precompute cost,
  not size. The old `~8.5 KB` figure for LONG's tables is corrected to
  the measured 8,448 B.

  §3 now also states plainly that *neither* profile serves a
  memory-bound consumer, since both trade only table memory and assume
  code is cheap, and points at #51 for the compact back-end.

- **Contract currency v0.10.6 → v0.11.0.** v0.10.7 registers `c64-mlkem`
  and states "no existing adopter is affected" — N/A. v0.11.0 adds two
  **zero-consumer carve-outs**, both N/A here: §1 (a library onboarding
  with no released consumers SHOULD NOT export the bare `LIB_VERSION_*`
  forms) and §6.5 (such a library SHOULD be "born prefixed" rather than
  waiting for MAJOR).

  Both are recorded rather than merely dismissed, because §6.5 is the
  clause that would otherwise have unlocked this library's deferred
  member-basename rename. It does not: c64-polyval is one of the four
  incumbents v0.11.0 names as unaffected, and §6.5's scope test — "no
  tagged release that any consumer pins" — is now definitively failed,
  `c64-aes256-ecdsa` having become a declared consumer pinning a tag on
  2026-08-23. The MAJOR deferral stands, and archive members cannot
  dual-name, so there is no transitional path short of v1.0.0.

  `API.md` §9's heading had drifted further than `CLAUDE.md`'s — it
  still read v0.10.3 — and is also corrected.
- **Post-v0.7.1 currency**: the "current release attestation", adoption
  heading, `make dist` example, layout heading, and release-notes
  template pointer all still named v0.7.0. `make consumer-check-noaes`
  is added to the build block and the `test/` layout, noted there as
  not vendored into the tarball.

### Fixed

- **`ZP_CONFIG_NO_EXPORTS` was not consumer-reachable** ([issue
  #50](https://github.com/JC-000/c64-polyval/issues/50)).
  `src/constants_lib.inc` assigned it unguarded, and every library TU
  includes that header, so the documented supplies-own-slots route —
  `-D ZP_CONFIG_NO_EXPORTS=1` on the ca65 command line — was a hard
  `Symbol 'ZP_CONFIG_NO_EXPORTS' is already defined` in *every* TU
  rather than a redundant define. Now `.ifndef`-guarded; the default
  stays 1. Same defect and same one-line shape as
  [c64-x25519#99](https://github.com/JC-000/c64-x25519/issues/99),
  fixed there in v0.11.1. Reported from `c64-aes256-ecdsa`, this
  library's first declared consumer, during its v0.7.1 integration.

  Verified: the issue's exact repro now assembles clean; `make lib
  CONTRACT_DEFINES='-D ZP_CONFIG_NO_EXPORTS=1'` builds and its
  `zp_config.o` exports **0** symbols, while the default build still
  exports all **13**; `build/polyval.prg` byte-identical to v0.7.1;
  suite 376/376 passed, 6 skipped.

## v0.7.1 — 2026-08-23

Consumer-unblocking **PATCH**. The POLYVAL-only archives
(`polyval-long.a` / `polyval-short.a`) exported the AES + GCM-SIV BSS
block and so could not be linked by any consumer that owns its own AES
— which is exactly what those two archives exist for. No exported
surface was removed or renamed, no manifest value moved, and the linked
PRG is byte-identical to v0.7.0 on both profiles, so
`LIB_POLYVAL_ABI_VERSION` stays 1.

### Fixed

- **`polyval-long.a` / `polyval-short.a` exported the AES + GCM-SIV BSS
  block, making the POLYVAL-only archives unlinkable by the very
  consumers they exist for** ([issue
  #47](https://github.com/JC-000/c64-polyval/issues/47)). `src/data.s` is
  a single monolithic BSS TU and `data.o` is archived whole into every
  variant, so `LIB_POLYVAL_NO_AES` gated the §5 manifest rows (issue #23)
  but never the storage those rows enumerate. The two POLYVAL-only
  archives therefore shipped 21 AES/GCM-SIV BSS exports — `aes_state`,
  `aes_current_key`, `aes_expanded_key`, `aes_mc_a0..b3` and the full
  `gcmsiv_*` set — and any consumer defining its own AES or GCM-SIV hit
  `ld65: Error: Duplicate external identifier`. This is issue #23's
  defect class one layer down: #23 fixed the enumeration, not the thing
  enumerated. The AES and GCM-SIV BSS blocks are now gated on
  `.ifndef LIB_POLYVAL_NO_AES`; POLYVAL references none of them.

  Found while `c64-aes256-ecdsa` — which ships its own AES-256 and its
  own GCM-SIV — was adopting the contract and consuming this library;
  all 21 symbols collided with symbols it defines.

  **No manifest change.** `LIB_POLYVAL_RESIDENT_BYTES` is code+rodata
  only (BSS excluded per SPEC §5) and `LIB_POLYVAL_COLD_BYTES` is
  code-span only, so both NO_AES rows are unaffected. Re-measured after
  the fix with the scratch-LOADADDR method `src/lib_manifest.s` records:
  LONG `$4000..$503F` = 4160 and SHORT `$4000..$752D` = 13614, both
  matching the 2026-08-15 values exactly. `build/polyval.prg` is
  byte-identical to master on both profiles, and the suite is unchanged
  at 376/376 passed, 6 skipped.

### Added

- **`make consumer-check-noaes`** — regression guard for the above.
  Links `test/consumer_stub_noaes.s`, which deliberately *defines* its
  own `aes_state` and `gcmsiv_tag`, against the real `polyval-long.a`
  and `polyval-short.a` archives; a re-leak fails the link. Verified to
  fail on the pre-fix tree and pass after, on both profiles. Uses
  `.forceimport` so ld65 actually extracts the archive members — a plain
  `.import` of an unreferenced symbol is dropped by ca65 and would leave
  the guard toothless.

### Documentation

- **Release-flow corrections learned by running it** ([PR
  #45](https://github.com/JC-000/c64-polyval/pull/45)): step 2 said "all
  four configurations" when v0.7.0 brought the archive count to five, so
  it now enumerates per shipped archive and instructs counting rows
  against the `lib-polyval-*` target list rather than against the
  previous release's table — counting against the last release is how it
  went stale. Step 3 records that the notes stamper is fail-closed and
  what a refusal means (a second 64-hex hash, or a literal placeholder
  token in prose): fix the notes, not the guard.
- **`docs/precalc-tables.md` archive membership** — the `aes_sbox` /
  `aes_inv_sbox` rows listed the AEAD bundle as `polyval.a` /
  `polyval-gcmsiv.a`, omitting `polyval-gcmsiv-short.a`, which ships
  `tables.o` and enumerates both S-boxes in its own §8.4 manifest
  (verified from inside the archive). The prose on the two independent
  axes is extended with the case v0.7.0 introduced: `polyval-short.a`
  and `polyval-gcmsiv-short.a` are both `PROFILE=short` yet differ in
  AES membership, which is precisely why profile alone cannot express
  that axis.
- **`README.md` build block** listed only two of the five archive
  targets after `lib-polyval-gcmsiv-short` was added; all five are now
  shown, each labelled with its profile and AES membership.

## v0.7.0 — 2026-08-15

The SHORT+AEAD reachability release. A v0.x **MINOR** bump: a new §6.1
archive target (`lib-polyval-gcmsiv-short`) is new consumer-visible
surface, so MINOR rather than PATCH — but nothing exported was removed
or renamed, so `LIB_POLYVAL_ABI_VERSION` stays 1 and the linked PRG
remains byte-identical to v0.4.1 on both profiles.

The cycle closed a defect in which the SHORT+AEAD configuration was
documented and recommended for RFC 8452 per-message `H`, yet no archive
delivered it — and the near-miss invocation exited 0 while shipping an
unlinkable archive whose §6.4 manifest misdescribed it
([#40](https://github.com/JC-000/c64-polyval/issues/40)). c64-polyval#40
became the upstream motivating case for contract SPEC v0.10.5's §6.3
*looks-reachable* rule.

Footprint values per (profile × variant), declared (SPEC §6.6
obligation 2 — one tag now carries **five** archive rows; no declared
value moved this cycle):

| Archive / configuration | RESIDENT | COLD |
|---|---|---|
| `polyval.a` / `polyval-gcmsiv.a` (LONG AEAD) | 6656 (unchanged) | 1280 (unchanged) |
| `polyval-gcmsiv-short.a` (SHORT AEAD) | 16128 (**new archive**) | 3072 (**new archive**) |
| `polyval-long.a` (LONG, no AES) | 4352 (unchanged) | 1280 (unchanged) |
| `polyval-short.a` (SHORT, no AES) | 13824 (unchanged) | 3072 (unchanged) |

The SHORT AEAD pair (16128 / 3072) is not new *as a value* — v0.6.1
already declared it for the configuration `API.md` §9.4 listed with `—`
in its Archive column. v0.7.0 is the release in which an archive finally
carries it.

### Added

- **`make lib-polyval-gcmsiv-short`** — new SPEC §6.1 archive target
  producing `build/lib/polyval-gcmsiv-short.a`: the full AEAD bundle
  (POLYVAL + AES-256 + GCM-SIV) on the **SHORT** profile, i.e. the RFC
  8452 per-message-`H` configuration
  ([#40](https://github.com/JC-000/c64-polyval/issues/40)). It follows
  the `lib-polyval-{long,short}` recursive clean-and-pin shape, so its
  `lib_manifest.o` is assembled under the same profile pin and the §5
  equates describe the archive they ship in (SPEC §6.4): `RESIDENT`
  16128 / `COLD` 3072.
- **Archive-goal configuration guard.** A `PIN_` table in the `Makefile`
  declares each archive goal's required
  `(POLYVAL_PROFILE × LIB_POLYVAL_NO_AES)` pair and asserts it at parse
  time, so a mismatched invocation is rejected before any object is
  assembled. Beyond the SHORT+AEAD case below, this closed two silent
  wrong-artifact paths found in review: naming
  `build/lib/polyval-gcmsiv-short.a` at the default profile shipped LONG
  code under the `-short` name, and `build/lib/polyval-short.a` shipped
  SHORT code carrying the LONG AEAD manifest value (6656 rather than
  13824) — incoherent, §6.4-violating and pre-existing. It also rejects
  `make lib POLYVAL_NO_AES=1` (AEAD member set, NO_AES manifest).

### Fixed

- **Release-notes stamping could silently falsify the byte-identity
  receipt.** `tools/build_release.sh` reset *every* 64-hex hash in the
  notes to the attestation placeholder, then stamped the tarball's hash
  over all of them with an unbounded `str.replace`. Since CLAUDE.md's
  post-[#37](https://github.com/JC-000/c64-polyval/issues/37) release
  flow requires a worktree-rebuild receipt in the notes, that rewrote
  the receipt's per-profile PRG hashes into a row of identical values
  still shaped like a passing identity check. The reset is now scoped to
  the `| **SHA256** |` attestation row, and stamping aborts unless
  exactly one placeholder of each kind is present. Measured on a scratch
  copy before fixing, and the new guard immediately caught a second live
  instance (prose in the v0.7.0 notes naming the placeholder token).

- **SHORT+AEAD was documented but undeliverable, and failed silently.**
  `LIB_AEAD_OBJS` hardcoded `polyval_long.o` while `POLYVAL_PROFILE`
  still reached `CA65FLAGS`, so `make lib POLYVAL_PROFILE=short` exited
  0 and archived the LONG multiply against a SHORT-assembled `data.o`
  and `lib_manifest.o`. The result was unlinkable (`polyval_long.o`
  imports `polyval_htable8_s*` / `polyval_reduce8_s*`, which SHORT
  `data.o` does not export) *and* SPEC §6.4-violating (the manifest
  claimed the SHORT footprints over LONG code). `ar65` cannot detect
  either. `LIB_AEAD_OBJS` now uses `$(POLYVAL_PROFILE_OBJ)`, and the
  unpinned `lib` / `lib-polyval-gcmsiv` targets reject a non-`long`
  profile at parse time — they do not `make clean` first, so under a
  profile switch they would otherwise reuse stale objects from the
  other profile. `API.md` §9.4's footprint table previously listed this
  configuration with `—` in the Archive column; it now names the
  archive. Existing archives (`polyval.a`, `polyval-gcmsiv.a`,
  `polyval-long.a`, `polyval-short.a`) and both PRGs are byte-identical
  across this change.

### Documentation

- SPEC currency **v0.10.4 → v0.10.6** (both tagged upstream 2026-08-15). The
  new §6.3 *looks-reachable* rule — a build knob naming a variant/profile
  axis MUST, on every §6.1 target accepting it, select that axis in both
  member selection and assembly configuration or reject the invocation
  loudly — is satisfied by the `PIN_` table's parse-time assert; no code
  change was required. c64-polyval#40 is the clause's shape-2 motivating
  case, and the `OPT_DATETIME` finding from its verification became the
  clause's checkability note upstream. `README.md`'s contract line was
  additionally two versions stale (v0.10.3) — it tracked neither this
  bump nor the v0.10.4 one. New `API.md` §9.5 entry for §6.3; `CLAUDE.md`
  records the rule and its `PIN_`-table discharge. **v0.10.6** enumerates
  the §8.3 provider surface (`ct_mul_8x8`, the SMC operand pair,
  `poly_prod_lo`/`_hi`) and requires a deferral gate to leave `.import`s
  behind for every name it un-defines — N/A here, verified by grep rather
  than assumed: the only §8.1–§8.3 names anywhere in this tree are the
  existing N/A declarations plus a doc-comment example in
  `precalc_table.inc`, and the library has no deferral switch. Also
  corrects two §6 target enumerations left at four entries when
  `lib-polyval-gcmsiv-short` was added.

- SPEC currency v0.10.3 → **v0.10.4**: the §6.3 clarification scoping
  the "no further target matrix" posture to *define-reachable*
  combinations, and requiring a §6.1 target for any documented axis
  that changes an archive's member set. `API.md` §9.5 gains a
  member-set-axis subsection; `README.md` "Profiles" and `CLAUDE.md`
  gain the profile-is-a-build-time-axis note. The gap this closes
  predated v0.10.4 — §6.3 ¶1's existing MUST already covered it.

- Post-release review of v0.6.1
  ([#37](https://github.com/JC-000/c64-polyval/issues/37)): the
  worktree-rebuild byte-identity receipt was produced post-hoc (claim
  reproduces exactly — v0.4.1 baseline rebuild hashes match v0.6.1 on
  both profiles) and appended to the release page and the on-disk
  notes; the release page's relative `CHANGELOG.md` link replaced
  with an absolute blob URL. The fleet's pre-tag release-PR review
  gate is adopted as release-flow step 0 in CLAUDE.md — releases now
  stage as PRs and wait for the review comment before tagging.
  README: dist example generalized to `vX.Y.Z` (was stale at
  `v0.5.0`) and the attestation/receipt practice documented.

## v0.6.1 — 2026-08-15

The contract v0.10.x alignment roll-up. A v0.x **PATCH** bump per this
library's own policy (bugfix with no API change): the §6.6 footprint
corrections change exported equate *values* only — no symbols added,
removed, or renamed; `LIB_POLYVAL_ABI_VERSION` stays 1 — and the
linked PRG remains byte-identical to v0.4.1 on both profiles.

Footprint deltas per (profile × variant), declared values (SPEC §6.6
obligation 2; actual code size is unchanged — these are declaration
corrections, not growth):

| Archive / configuration | RESIDENT | COLD |
|---|---|---|
| `polyval.a` / `polyval-gcmsiv.a` (LONG AEAD) | 6500 → 6656 (+156) | 1200 → 1280 (+80) |
| `POLYVAL_PROFILE=short` link (SHORT AEAD) | 16000 → 16128 (+128) | 3000 → 3072 (+72) |
| `polyval-long.a` (LONG, no AES) | 6500 → 4352 (−2148) | 1200 → 1280 (+80) |
| `polyval-short.a` (SHORT, no AES) | 16000 → 13824 (−2176) | 3000 → 3072 (+72) |

### Documentation

- Alignment pass against contract SPEC v0.10.3 (all-clauses
  mechanical re-verification: canonical `precalc_table.inc`
  byte-identical, §1/§2 export inventories, §4 annotations, §5/§6.6
  per-archive values, §6.2 variables, PRG hashes on both profiles —
  all pass, no code change needed): currency refresh v0.10.0 →
  v0.10.3 across README / API.md §9 / CLAUDE.md. v0.10.1 (stable-
  numbers reorder), v0.10.2 (SPEC snippet fixes — this repo audited
  clean for both forms), and v0.10.3 (§8.4 heading promoted; our
  citations retroactively correct) require no adoption work.

### Changed

- **`LIB_POLYVAL_RESIDENT_BYTES` / `LIB_POLYVAL_COLD_BYTES` value
  corrections** per c64-lib-contract SPEC v0.10.0
  [§6.6](https://github.com/JC-000/c64-lib-contract/blob/main/SPEC.md)
  (consumer footprint asserts, contract
  [#69](https://github.com/JC-000/c64-lib-contract/issues/69) /
  [#76](https://github.com/JC-000/c64-lib-contract/issues/76) phase 2).
  Two defects fixed in `src/lib_manifest.s`:
  1. *Unsafe rounding* — both equates rounded DOWN from measured
     (6567 → 6500, 1239 → 1200 LONG; 16021 → 16000, 3059 → 3000
     SHORT), so a consumer's `declared ≤ budget` assert could pass
     while the actual footprint overran. §6.6 obligation 1: each
     value must be ≥ the measured segment sum, rounded UP — fleet
     convention next 256-byte boundary.
  2. *Per-archive accuracy* — values were gated on `POLYVAL_PROFILE`
     only, so `polyval-long.a` / `polyval-short.a` (built with
     `-D LIB_POLYVAL_NO_AES=1`, containing no `tables.o` /
     `aes_*.o` / `gcm_siv.o`) shipped manifests claiming ~2.3 KB of
     AES+GCM-SIV code they do not contain (SPEC §6.4/§6.6; same
     defect class as issue #23). Both equates now gate on
     `POLYVAL_PROFILE` × `LIB_POLYVAL_NO_AES`.

  Measured (lib_only.cfg link of each archive's exact member set,
  ca65/ld65 V2.18) → declared:

  | Configuration (archive) | RESIDENT | COLD |
  |---|---:|---:|
  | LONG AEAD (`polyval.a` / `polyval-gcmsiv.a`) | 6567 → 6656 | 1239 → 1280 |
  | SHORT AEAD (`make POLYVAL_PROFILE=short` link) | 16021 → 16128 | 3059 → 3072 |
  | LONG NO_AES (`polyval-long.a`) | 4160 → 4352 | 1047 → 1280 |
  | SHORT NO_AES (`polyval-short.a`) | 13614 → 13824 | 2867 → 3072 |

  Linked PRG output stays byte-identical on both profiles (equates
  emit no segment data). Docs: API.md §9 currency to SPEC v0.10.0
  (v0.9.2 was doc-only, already satisfied), §9.4 per-archive value
  table + safe-direction rationale, §9.5 §6.6 adoption with the
  polyval-ized consumer assert snippet and §6.7 declared N/A (all
  buffers segment-resident; no §8.x placement equates); release flow
  now requires per-(profile × variant) footprint deltas in release
  notes per §6.6 obligation 2.

## v0.6.0 — 2026-08-14

The c64-lib-contract v0.9.x alignment roll-up — polyval's re-tag in
the [#76](https://github.com/JC-000/c64-lib-contract/issues/76)
phase-3 coordinated adopter wave (gated on the upstream v0.9.0 tag).
A v0.x **MINOR** bump: the §6.2 `CONTRACT_DEFINES` /
`CONTRACT_ZP_DEFINES` make-variable surface is new; nothing exported
by any archive was removed or renamed, so `LIB_POLYVAL_ABI_VERSION`
stays 1. Linked PRG output remains byte-identical to v0.4.1 on both
profiles — every change since is equate-, export-, gating-, cfg-, or
docs-level.

### Removed

- The bare `zp_dummy` `.exportzp` in `src/zp.s` (with its orphaned
  `.globalzp` template line in `src/include/zp.inc`), per the
  c64-lib-contract [#76](https://github.com/JC-000/c64-lib-contract/issues/76)
  R2 ruling and the [#83](https://github.com/JC-000/c64-lib-contract/issues/83)
  bare-`zp_*`-name collision class. It was a pre-contract porting
  placeholder: app-layer only (`zp.o` is in `APP_MODULES`, never a
  member of any §6 archive), imported by nothing, and not part of the
  §2 surface or the `LIB_POLYVAL_ZP_USAGE_BYTES` sum — so no consumer
  export surface shrinks and no ABI-counter implication. The
  `ZEROPAGE` placeholder byte itself remains (unexported), and
  `zp.inc` now shows the prefixed-name pattern instead of a live
  declaration. Exported-vs-summed ZP audit (per the #76 R2
  all-adopters action): 13 exported slots, all `polyval_`/`pv_`
  prefixed, widths sum 45 = `LIB_POLYVAL_ZP_USAGE_BYTES`.

### Documentation

- Consumer version-guard snippets aligned with the canonical SPEC §1
  `.assert`/`lderror` form (contract
  [#73](https://github.com/JC-000/c64-lib-contract/issues/73), fixed
  upstream in v0.8.1): `src/lib_version.s`'s header comment showed an
  `.if`-on-imported-symbol gate that never assembled; API.md §9.7's
  combined `.assert` used a `\` line continuation ca65 rejects
  without `.linecont +`. Both snippets are now single-line `lderror`
  asserts, compile-tested.
- Contract-currency: SPEC v0.9.1 re-lands the §6.5 suppression-gate
  and §2 registry-gate amendments the v0.9.0 merge missed, and its
  restated §6.2 ZP-scoping rule cites this library's PR #34
  measurements as the defining-TU-direction evidence.
- Consumer ZP-override snippets fixed for two copied-snippet defect
  classes the contract catalogued (SPEC v0.7.1 and v0.8.6, which asked
  adopters to re-check): `src/zp_config.s`'s host-override comment
  said `--asm-define` (ca65 rejects it — cl65's spelling) with an
  unquoted `$40` (the shell expands `$4` + `0`, silently placing the
  slot at `$00`); `src/lib_manifest.s`'s override note had the same
  spelling. Snippets now show `-D polyval_acc=0x40` (measured: the
  slot exports at `$40`) with the quoting rule and make-recipe `0x`
  preference stated.
- Contract-currency refresh to SPEC v0.9.0 (API.md §9, README,
  CLAUDE.md): v0.8.4 (`ZEROPAGE` exempt from §4 — matches existing
  usage) and v0.8.6 ($-hex snippet rule — already adopted via the
  snippet fixes below) are doc-only; v0.8.5's §8.1/§8.2 export
  discipline is N/A (no shared-primitive equates emitted); v0.9.0's
  §2 ZP prefix registry registers `polyval_` and `pv_` to this
  library (noted in API.md §9.2), and its §6 chapter is adopted in
  the Added entry below. `src/zp_config.s`'s host-override comment
  now leads with the §6.2 make-level route.
- Contract-currency refresh to SPEC v0.8.3: v0.8.2 is the upstream
  spec-tagging policy (issue #71), v0.8.3 corrects §4's measured risk
  table per adopter reports (contract
  [#78](https://github.com/JC-000/c64-lib-contract/issues/78) — this
  library's §9.8/cfg measurements were part of the record). The cfg
  annotations and API.md §9.8 now state the corrected semantics: both
  ld65 diagnostics are shape-conditional (the align warning needs a
  source-level `.align`; the bss warning keys on byte value), and the
  `type = bss` mutation additionally displaces everything after the
  hole in `c64.cfg`, where file-emitting `DATA` follows the segment.

### Added

- c64-lib-contract v0.9.0 §6.2 consumer-defines forwarding (contract
  [#76](https://github.com/JC-000/c64-lib-contract/issues/76) phase 1):
  the Makefile now accepts the two contract-normative variables
  `CONTRACT_DEFINES` (global ca65 `-D` flags) and `CONTRACT_ZP_DEFINES`
  (§2 ZP slot overrides, e.g.
  `make lib CONTRACT_ZP_DEFINES='-D polyval_acc=0x40'`), both `?=`
  empty and appended to `CA65FLAGS`, so consumer defines reach every
  §6.1 target — including the recursive `lib-polyval-{long,short}`
  builds — without editing the Makefile or clobbering `CA65FLAGS`.
  Delivering `CONTRACT_ZP_DEFINES` to *every* member recipe is this
  library's conformant reading of the SPEC's "only the ZP-defining
  TU(s)" scope: c64-polyval has zero `.importzp` sites for its own
  slots (each TU bakes the equates via `constants_lib.inc` →
  `zp_config.s` `.ifndef` guards), so every member TU is a ZP-defining
  TU and a `zp_config.o`-only delivery would export an overridden
  address other members never baked. Measured: an overridden
  `polyval_acc=0x40` lands in `zp_config.o`'s exports in `polyval.a`
  and (via automatic sub-make propagation) `polyval-short.a`, and
  `lib-verify` / `consumer-check` link clean under the override.
  The rest of the v0.9.0 §6 chapter needs no code change, verified and
  documented in `API.md` §9.5: archive basenames already canonical
  (`polyval[-<variant>].a`), `lib-app-owned` N/A (no §8.x primitive
  consumed), §6.4 per-variant manifests already conformant (both
  halves), `lib-verify` grandfathered in the reserved `lib-*` namespace
  until next MAJOR, and the §6.5 `polyval_`-prefixed archive member
  basenames recorded as a next-MAJOR item.
- c64-lib-contract v0.8.0 §4 segment-placement declarations
  (contract [#63](https://github.com/JC-000/c64-lib-contract/issues/63)):
  load-bearing cfg attributes are now declared as comments on the
  segment lines of `src/c64.cfg` and `src/lib_only.cfg` — `type = ro`
  on `LIB_POLYVAL_AES_RODATA` (correctness: 522 initialised S-box/rcon
  bytes are dropped under `type = bss`; ld65 warns but links) and
  `align = $100` on `LIB_POLYVAL_HTABLE` /
  `LIB_POLYVAL_LONG_HTABLE8` / `LIB_POLYVAL_LONG_REDUCE8`
  (performance-only, and declared as such — the library is not
  constant-time, API.md §6; dropping the attribute is fully silent
  since `src/data.s` carries no `.align`). New API.md §9.8 documents
  the declarations and the segments deliberately left undeclared;
  README §4 bullet, API.md §9 currency paragraph (v0.7.5 + v0.8.0),
  and CLAUDE.md updated. Docs and cfg comments only — linked PRG
  output is byte-identical on both profiles.

## v0.5.0 — 2026-08-13

Adopts the [c64-lib-contract](https://github.com/JC-000/c64-lib-contract)
v0.7.0 prefixed-export surface (§1 + §8.4, contract at SPEC v0.7.3 at
release time) and fixes a §8.0 manifest-accuracy defect in the
POLYVAL-only archives. This is a v0.x **MINOR** bump: new exported
symbols, no removals or renames, `LIB_POLYVAL_ABI_VERSION` stays 1.
Linked PRG output is byte-identical to v0.4.1 on both profiles —
every change is equate-, export-, gating-, or docs-level.

### Added

- §1 prefixed version exports
  ([#21](https://github.com/JC-000/c64-polyval/issues/21), via
  [PR #26](https://github.com/JC-000/c64-polyval/pull/26)):
  `src/lib_version.s` now exports `LIB_POLYVAL_VERSION_{MAJOR,MINOR,PATCH}`
  and `LIB_POLYVAL_ABI_VERSION` as the permanent, collision-free form.
  The deprecated bare `LIB_VERSION_*` / `LIB_ABI_VERSION` names remain
  exported by default (required through contract v0.x, removed at
  v1.0), are gated on `LIB_NO_BARE_EXPORTS`, and alias the prefixed
  literals so the two forms cannot drift. `test/consumer_stub.s`
  imports both forms, so `make consumer-check` guards the full set.
- §8.4 prefixed precalc-table exports
  ([#22](https://github.com/JC-000/c64-polyval/issues/22), via
  [PR #24](https://github.com/JC-000/c64-polyval/pull/24)):
  `src/precalc_table.inc` re-copied byte-for-byte from the contract
  root (SHA256-verified); all five `LIB_PRECALC_TABLE` call sites pass
  `"POLYVAL"` as the fifth argument, emitting
  `LIB_POLYVAL_PRECALC_<name>_{SIZE,REGION,SHARED}` alongside the
  bare triple (same `LIB_NO_BARE_EXPORTS` gating). Table names stay
  unprefixed per SPEC §8.1. Audit greps move from `LIB_PRECALC_` to
  `_PRECALC_`.
- Makefile `POLYVAL_NO_AES=1` knob (passes `-D LIB_POLYVAL_NO_AES=1`),
  set automatically by the `lib-polyval-{long,short}` targets.

### Fixed

- §8.0 manifest accuracy
  ([#23](https://github.com/JC-000/c64-polyval/issues/23), via
  [PR #25](https://github.com/JC-000/c64-polyval/pull/25)):
  `polyval-long.a` / `polyval-short.a` no longer export
  `LIB_*PRECALC_aes_sbox_*` / `_aes_inv_sbox_*` equates describing
  512 B of AES tables those archives do not contain (`tables.s` is a
  member of the AEAD bundle only). The AES rows are gated on
  `LIB_POLYVAL_NO_AES` — archive membership is an axis
  `POLYVAL_PROFILE` cannot express, since `polyval-long.a` and
  `polyval-gcmsiv.a` are both PROFILE=long. Verified by `ar65 x` +
  `od65 --dump-exports` on every archive's extracted manifest member.
- API.md §9.1 value table had said `LIB_VERSION_PATCH` = 0 since the
  v0.4.1 release bumped the export to 1 — the §9.1 drift class hitting
  the docs side this time. The release checklist now covers the table.

### Changed

- `src/lib_version.s`: `LIB_POLYVAL_VERSION_MINOR` 4 → 5,
  `LIB_POLYVAL_VERSION_PATCH` 1 → 0 (bare aliases follow), with the
  matching `VERSION` bump.
- Docs currency: contract references bumped to SPEC v0.7.3 across
  README / API.md §9 / CLAUDE.md; `docs/precalc-tables.md` and
  API.md §9.6 now state which archives carry each table and the
  od65-reads-objects-not-archives audit caveat.

## v0.4.1 — 2026-07-28

Docs-only **PATCH** release: rolls up the issue-#19 turbo-scaling
documentation and a documentation-currency pass (contract SPEC v0.4.1
references, corrected test counts). The only source change is the
`LIB_VERSION_PATCH` bump itself — no code, ABI, or binary changes.

### Documentation

- Zero-REU / turbo-clean scaling documented as an explicit contract
  feature ([#19](https://github.com/JC-000/c64-polyval/issues/19),
  prompted by c64-nist-curves #69/#71): new README "Turbo /
  accelerated hosts" section and Features bullet; API.md §1 platform
  statement strengthened, §3 turbo-scaling paragraph added, §9.3
  expanded with the consumer-facing guarantees and a stated policy
  that any future REU-resident variant must ship as an *optional
  profile* with a manifest delta, never the default path (also in the
  `src/lib_manifest.s` §3 comment block). Comment/docs only — no code
  or binary changes.
- Contract-currency refresh: c64-lib-contract references in README,
  API.md §9, and CLAUDE.md bumped from SPEC v0.4.0 to SPEC v0.4.1.
  The contract's v0.4.1 is itself doc-only (no symbol, macro,
  section, or build-target semantics changed), so no adoption work
  was required — verified against the upstream SPEC changelog, and
  `src/precalc_table.inc` re-confirmed byte-identical to the
  canonical root file.
- README test section corrected: the `test_gcmsiv_polyval.py`
  end-to-end suite had grown to 165 tests (README still said "~15");
  expected totals (376/376 pass, 6 AAD-by-design skips) now stated.
  Release example generalized to `vX.Y.Z`.

### Changed

- `src/lib_version.s`: `LIB_VERSION_PATCH` 0 → 1 (with the matching
  `VERSION` file bump — the two are checked together per the v0.3.0
  drift lesson, API.md §9.1).

## v0.4.0 — 2026-07-16

Adopts [c64-lib-contract](https://github.com/JC-000/c64-lib-contract)
SPEC §8.0 (the "catch loop" precalculated-table enumeration, added to
the contract in v0.3.1 and still applicable at the contract's current
v0.4.0). §8.1–§8.3 (shared 8×8 quarter-square-multiply primitives)
remain N/A for c64-polyval — GF(2^128) carry-less multiplication has
no equivalent shared shape with the elliptic-curve / ChaCha20
libraries — so no `LIB_POLYVAL_SHARED_PRIMITIVES` equate is emitted.
This is a v0.x **MINOR** bump: new exported symbols, no removals.

### Added

- `src/precalc_table.inc` — canonical `LIB_PRECALC_TABLE` macro,
  copied verbatim from the contract repo per SPEC §8.0.
- `src/lib_manifest.s` now `.include`s it and registers five tables
  that clear the §8.0 floor (≥ 256 B AND hot-loop-read /
  page-aligned): `polyval_htable` (256 B, both profiles),
  `polyval_htable8` / `polyval_reduce8` (4096 B each, LONG profile
  only), `aes_sbox` / `aes_inv_sbox` (256 B each, both profiles).
  All classified `PRECALC_SHARED_NO` (algorithm-specific).
- `docs/precalc-tables.md` — the required human-readable enumeration:
  name, size, region, source file, classification, and rationale per
  table, plus the below-floor exempt list.
- `tools/build_release.sh` now stages `docs/precalc-tables.md` into
  the release tarball.

### Fixed

- `src/lib_version.s` exported `LIB_VERSION_MINOR = 2` /
  `LIB_VERSION_PATCH = 0` (i.e. "v0.2.0") ever since the v0.3.0
  release — the release commit (`0e7dd34`) bumped the `VERSION` file
  and `API.md` §9.1's documented value to 0.3.0 but never updated
  `src/lib_version.s` itself, so a consumer `.assert`ing
  `LIB_VERSION_MINOR >= 3` per `API.md` §9.6's own worked example
  would have failed to link against the actual v0.3.0 release. Now
  correctly exports 0.4.0.

## v0.3.0 — 2026-05-20

Adopts the [c64-lib-contract](https://github.com/JC-000/c64-lib-contract)
SPEC v0.1.0 in full. All six SPEC sections that apply to c64-polyval
land in this release (§3 is N/A — c64-polyval makes no REU claims).
This is a v0.x **MINOR** bump per the contract's §7 versioning rule
(breaking surface changes are allowed pre-v1.0). Consumers vendoring
c64-polyval need to update their `.import` / `.importzp` lists for
the renamed ZP slots and their `.segment` references in any custom
ld65 configs.

### Added

- `src/lib_version.s` — c64-lib-contract §1 surface. Exports
  `LIB_VERSION_MAJOR`, `LIB_VERSION_MINOR`, `LIB_VERSION_PATCH`, and
  `LIB_ABI_VERSION` as absolute equates, for consumer-side assemble-
  time version gating.
- `src/zp_config.s` — c64-lib-contract §2 surface. Every zero-page
  slot the library claims is now declared in a dedicated, `.ifndef`-
  guarded, `.exportzp`-ed translation unit. Suppression flag
  `ZP_CONFIG_NO_EXPORTS` mirrors the c64-x25519 / c64-nist-curves
  idiom.
- `src/lib_manifest.s` — c64-lib-contract §5 surface. Exports
  `LIB_POLYVAL_ZP_USAGE_BYTES` (45), `LIB_POLYVAL_REU_BANKS_USED`
  (0), and the profile-conditional `LIB_POLYVAL_RESIDENT_BYTES` /
  `LIB_POLYVAL_COLD_BYTES` so consumers can size-check the library
  at assemble time.
- Four new ar65 archive `make` targets (c64-lib-contract §6):
  - `make lib` — full AEAD bundle at `build/lib/polyval.a`
    (POLYVAL LONG + AES-256 + GCM-SIV).
  - `make lib-polyval-long` — POLYVAL LONG primitive only.
  - `make lib-polyval-short` — POLYVAL SHORT primitive only.
  - `make lib-polyval-gcmsiv` — explicit name for the AEAD bundle
    (currently byte-identical to `make lib`).

### Changed

- Segment names library-wide carry the `LIB_POLYVAL_*` prefix per
  c64-lib-contract §4. The library `.s` files now `.segment
  "LIB_POLYVAL_<VARIANT>_<KIND>"` (e.g. `LIB_POLYVAL_AES_CODE`,
  `LIB_POLYVAL_HTABLE`) instead of bare `CODE` / `RODATA` / `BSS`.
  `src/c64.cfg` and `src/lib_only.cfg` carry SEGMENTS{} aliases back
  to the same memory areas as before; the linked PRG is byte-
  identical to the v0.2.0 baseline.
- Shared ZP slots renamed from `zp_*` to `polyval_*_*` (e.g.
  `zp_ptr` → `polyval_zp_ptr`, `zp_round` → `polyval_aes_round`).
  Cross-library prefix isolation per c64-lib-contract §2.
- The pre-v0.3.0 `make lib` target (library-only verification PRG
  link at `$4000`) is renamed to `make lib-verify`. The freed
  `make lib` name now produces the SPEC §6 ar65 archive at
  `build/lib/polyval.a`.

### Compatibility

This is a v0.x **MINOR** bump per c64-lib-contract SPEC §7
(breaking surface changes allowed pre-v1.0). Consumers vendoring
c64-polyval must:

1. Update `.importzp` lists: every `zp_*` slot (e.g. `zp_ptr`,
   `zp_round`, `zp_tmp1..tmp4`, `zp_ptr2`, `zp_temp`, `zp_count`)
   is renamed to its `polyval_*_*` form (see `src/zp_config.s` for
   the canonical names).
2. Update any custom ld65 cfg overlays referencing the old
   `CODE` / `RODATA` / `BSS` segment names — the library now
   emits `LIB_POLYVAL_*_*` segments.
3. Optionally add `.import LIB_ABI_VERSION` and an assemble-time
   `.assert LIB_ABI_VERSION = 1` gate, plus the SPEC §5 size
   asserts against `LIB_POLYVAL_ZP_USAGE_BYTES` &c.

The public POLYVAL / AES-256 / GCM-SIV entry-point names (§2.1,
§2.4, §2.7 in `API.md`) and their calling conventions are
unchanged.

Contract: [c64-lib-contract](https://github.com/JC-000/c64-lib-contract)
SPEC v0.1.0 adoption — closes #12 (§1), #13 (§2), #14 (§4),
#15 (§5), #16 (§6).

## v0.2.0 — 2026-05-15

- Repackage to c64-nist-curves library format
- Retire ACME assembler support; consolidate to ca65 (cc65 toolchain)
- Replace dual root/ca65 Makefiles with single top-level Makefile
- Move ABI surface from `abi_v1.inc` to `src/exports.inc`
- Add MIT LICENSE
- Source tarball release format (`make dist VERSION=…`) replaces `.lib` archive shipping
- Preserve `ca65/release/v0.1.0/` as historical artifact

## v0.1.0 — (earlier)

- Initial public release. POLYVAL + AES-256-GCM-SIV with ca65+ACME parallel
  builds, LONG/SHORT profiles, `.lib` archive release format.
- Frozen at `ca65/release/v0.1.0/`.
