# c64-polyval

POLYVAL (RFC 8452 §3) and AES-256-GCM-SIV authenticated encryption for the
Commodore 64. Hand-optimized 6502 assembly built with the ca65/ld65 toolchain,
shipped with two interchangeable POLYVAL profiles — a low-memory SHORT
build for short-message workloads (per-message H derivation) and a
high-throughput LONG build for session-stable H (TLS 1.3, WireGuard).

## Features

- POLYVAL GF(2^128) universal hash, byte-accurate against RFC 8452 test
  vectors. Two interchangeable multiply back-ends (SHORT / LONG).
- AES-256 ECB encrypt and decrypt, plus key expansion (T-table-free).
- AES-256-GCM-SIV AEAD (RFC 8452), up to 64 B plaintext per call, empty
  AAD only.
- Single stable public ABI across both POLYVAL profiles — consumers swap
  one for the other without source changes.
- Zero-REU / zero-I/O: pure CPU + RAM on every path, so it runs
  unmodified on expansion-less machines and scales with CPU clock on
  turbo hosts (see "Turbo / accelerated hosts" below).
- `make consumer-check` link gate that assembles `test/consumer_stub.s`
  against the public headers and links it against the library, catching
  ABI drift before a release.
- Reproducible source-tarball release format via `make dist`.

## Requirements

- [cc65](https://cc65.github.io/) toolchain (ca65 assembler + ld65 linker)
- [VICE](https://vice-emu.sourceforge.io/) emulator (for testing) with
  `x64sc`
- Python 3.10+ with
  [c64-test-harness](https://github.com/JC-000/c64-test-harness)

## Build

```bash
make                              # build build/polyval.prg (LONG profile, default)
make POLYVAL_PROFILE=short        # SHORT profile (low-memory, per-message H)
make POLYVAL_PROFILE=long         # LONG profile (high-throughput, stable H)
make lib                          # build/lib/polyval.a (full ar65 archive)
make lib-verify                   # library-only verification link (pre-v0.3.0 `make lib`)
make consumer-check               # assemble + link test/consumer_stub.s
make run                          # build then launch in VICE
make dist VERSION=v0.5.0          # reproducible source tarball
make clean                        # rm -rf build/
```

The Makefile maps `POLYVAL_PROFILE=short|long` to ca65's
`-D POLYVAL_PROFILE=1|2` and to `polyval_short.o` / `polyval_long.o`
at link time.

## Test

```bash
python3 tools/run_all_tests.py [--seed N] [--iterations N] [--verbose]
```

Runs both the `test_polyval_direct.py` regression suite (217 tests,
direct `jsr()` against every POLYVAL routine) and the
`test_gcmsiv_polyval.py` end-to-end suite (165 tests, RFC 8452 C.2
vectors + tampered-tag detection + random roundtrips; 6 of the C.2
vectors skip by design — non-empty AAD is unsupported) in parallel
under two VICE instances. Expected: 376/376 pass, 6 skip.

Individual suites can be run directly:

```bash
python3 tools/test_polyval_direct.py      # POLYVAL unit tests
python3 tools/test_gcmsiv_polyval.py      # AES-256-GCM-SIV end-to-end
python3 tools/benchmark_polyval.py        # CIA-timer cycle benchmarks
python3 tools/polyval_reference.py        # Python reference self-test (no VICE)
```

## Library contract

c64-polyval implements [c64-lib-contract](https://github.com/JC-000/c64-lib-contract)
(currently at SPEC v0.10.3) — see the
[SPEC](https://github.com/JC-000/c64-lib-contract/blob/main/SPEC.md)
and the
[adopters table](https://github.com/JC-000/c64-lib-contract/blob/main/adopters.md).
All sections that apply to a CPU-RAM-only crypto library with no
shared 8×8 quarter-square-multiply surface are covered:

- §1 — `LIB_POLYVAL_VERSION_MAJOR / _MINOR / _PATCH` and
  `LIB_POLYVAL_ABI_VERSION` exported from `src/lib_version.s`
  (SPEC v0.7.0 prefixed form), plus the deprecated bare
  `LIB_VERSION_*` aliases, gated on `LIB_NO_BARE_EXPORTS` until
  contract v1.0 removes them.
- §2 — every claimed zero-page slot declared in `src/zp_config.s`
  under the `polyval_*` prefix.
- §3 — N/A; c64-polyval makes no REU claims
  (`LIB_POLYVAL_REU_BANKS_USED = 0`).
- §4 — library `.segment` directives use the `LIB_POLYVAL_*`
  prefix; consumer ld65 configs can map them anywhere. Load-bearing
  placement attributes (SPEC v0.8.0) are declared as comments on the
  segment lines of `src/c64.cfg` / `src/lib_only.cfg`: `type = ro`
  on `LIB_POLYVAL_AES_RODATA` is correctness-critical (522
  initialised S-box/rcon bytes), `align = $100` on the three
  runtime-filled table segments is performance-only — see `API.md`
  §9.8.
- §5 — aggregate manifest equates (`LIB_POLYVAL_ZP_USAGE_BYTES`,
  `LIB_POLYVAL_RESIDENT_BYTES`, `LIB_POLYVAL_COLD_BYTES`,
  `LIB_POLYVAL_REU_BANKS_USED`) in `src/lib_manifest.s`. The two
  byte-count equates are per-archive and safe-direction per SPEC
  v0.10.0 §6.6: measured for each (profile × variant) archive and
  rounded UP to the next 256-byte boundary, so a consumer's
  `declared ≤ budget` assert implies `actual ≤ budget` — see
  `API.md` §9.4 for the per-archive value table. §6.7 (declared
  non-segment reservations) is N/A: every buffer is
  segment-resident, no placement equate reserves address space
  invisible to ld65 — see `API.md` §9.5.
- §6 — `make lib`, `make lib-polyval-long`, `make lib-polyval-short`,
  and `make lib-polyval-gcmsiv` produce ar65 archive bundles under
  `build/lib/` (canonical `polyval[-<variant>].a` basenames). Consumer
  defines reach every build per §6.2 via
  `CONTRACT_DEFINES` / `CONTRACT_ZP_DEFINES`, e.g.
  `make lib CONTRACT_ZP_DEFINES='-D polyval_acc=0x40'` — see
  `API.md` §9.5.
- §8 (shared primitives, §8.1–§8.3) — N/A; GF(2^128) carry-less
  multiplication shares no shape with the 8×8 quarter-square-multiply
  primitive the elliptic-curve / ChaCha20 libraries converged on.
- §8.0/§8.4 — precalculated-table enumeration (required of every
  adopter regardless of §8.1–§8.3 applicability): `src/precalc_table.inc`
  + `LIB_PRECALC_TABLE` invocations in `src/lib_manifest.s` with the
  v0.7.0 `"POLYVAL"` prefix argument, documented in
  [`docs/precalc-tables.md`](docs/precalc-tables.md). Manifest rows are
  gated so each §6 archive enumerates only the tables it actually
  ships.

See `API.md` §9 for the consumer-facing symbol surface and a worked
import example.

## API

See [`API.md`](API.md) for the complete integration reference:
public symbols and contracts, profile selection, zero-page layout,
calling conventions, known limitations, build integration, and the
canonical LIBRARY-vs-DEMO-APP file inventory consumers must follow
when linking.

A worked example for downstream consumers (`c64-wireguard`,
`c64-https`, ...) lives at [`test/consumer_stub.s`](test/consumer_stub.s):
it includes the public headers (`constants_lib.inc`,
`polyval_api.inc`, `exports.inc`), imports a representative slice of
the ABI, and `jsr`s each entry point. `make consumer-check` is the
gate that proves the public surface is stable for external use.

## Profiles

| Profile | multiply | precompute | tables | picks when |
|---|---:|---:|---:|---|
| SHORT | ~18,770 cy | ~29,385 cy | ~256 B | H rederived per message (RFC 8452 GCM-SIV) |
| LONG  | ~3,915 cy  | ~255,263 cy | ~8.5 KB | H stable across many blocks (TLS 1.3, WireGuard) |

Both profiles export an identical set of public symbols. The
practical crossover where LONG starts winning consistently is around
68 blocks (~1 KB of plaintext per message). Below that, SHORT hashes
a full message faster despite its slower per-block inner loop; above
that, LONG pulls ahead. See `API.md` §3 for the full discussion and
the math.

## Turbo / accelerated hosts

c64-polyval never touches the REU, any I/O register, or the KERNAL —
both profiles are pure CPU + RAM on every path
(`LIB_POLYVAL_REU_BANKS_USED = 0`). Two guarantees follow:

- Runs unmodified on expansion-less machines.
- Per-block cost **and** precompute scale ~linearly with CPU clock on
  accelerated hosts (Ultimate 64 / C64 Ultimate turbo, SuperCPU-class).
  There is no ~1 MHz-anchored wall-clock floor of the kind
  REU-DMA-bound hot paths hit, and the SHORT/LONG crossover
  (~68 blocks) is clock-invariant.

See `API.md` §3 for the scaling discussion and §9.3 for the policy any
future REU-resident variant must follow (optional profile with a
manifest delta — never the default path).

## Release

`make dist VERSION=vX.Y.Z` produces a reproducible source tarball
`c64-polyval-vX.Y.Z.tar.gz` rooted at the named git tag. Tagged
releases are published at
https://github.com/JC-000/c64-polyval/releases; consumers should pin
to a specific `vX.Y.Z` tag (typically as a git submodule) and consult
[`CHANGELOG.md`](CHANGELOG.md) before bumping.

## License

MIT. See [`LICENSE`](LICENSE).

## History

The v0.1.0 release shipped a `.lib`-archive distribution format under
`ca65/release/v0.1.0/` (two `ar65` archives `polyval_long.lib` /
`polyval_short.lib`, a stable `abi_v1.inc` header, attestation
results, and a canonical consumer example). That tree is preserved
verbatim in this repository for reproducibility of the prior
release, but new consumers should integrate against the v0.2.0
source-tarball format described in `API.md` §8 instead — the
`exports.inc` ABI header has superseded `abi_v1.inc`, and the
top-level `Makefile` has replaced the dual root + `ca65/` build
trees.
